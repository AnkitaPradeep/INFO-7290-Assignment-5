--Table for State
CREATE TABLE [Dim_State]
(
 [SPK] Int IDENTITY ,
 [StateAbbreviation] Nvarchar(10) NOT NULL,
 [StateName] Nvarchar(50) ,
 [StateFIPS] Nvarchar(50) 
)
go
ALTER TABLE [Dim_State] ADD CONSTRAINT [Key1] PRIMARY KEY ([StateAbbreviation])
go

-- Table for County
CREATE TABLE [Dim_County]
(
 [SPK] Int IDENTITY ,
 [CountyName] Nvarchar(50) ,
 [FIPS] Nvarchar(50) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL
)
go
ALTER TABLE [Dim_County] ADD CONSTRAINT [Key2] PRIMARY KEY ([StateAbbreviation])
go

-- Table for Zip
CREATE TABLE [Dim_Zip]
(
 [SPK] Int IDENTITY ,
 [Zip] Nvarchar(50) ,
 [town] Nvarchar(50) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL
)
go
ALTER TABLE [Dim_Zip] ADD CONSTRAINT [Key3] PRIMARY KEY ([StateAbbreviation])
go

-- Create foreign keys 
ALTER TABLE [Dim_County] ADD CONSTRAINT [Relationship1] FOREIGN KEY ([StateAbbreviation]) REFERENCES [Dim_State] ([StateAbbreviation]) ON UPDATE NO ACTION ON DELETE NO ACTION
go
ALTER TABLE [Dim_Zip] ADD CONSTRAINT [Relationship2] FOREIGN KEY ([StateAbbreviation]) REFERENCES [Dim_State] ([StateAbbreviation]) ON UPDATE NO ACTION ON DELETE NO ACTION
go